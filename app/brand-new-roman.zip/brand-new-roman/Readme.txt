Brand New Roman
Copyright © 2018 by Hello Velocity (hellovelocity.com).

This package contains:
Brand New Roman C
Brand New Roman BW

Both are open type svg fonts. The Color version of this font is not supported in all programs at the time of this writing.
**Currently no operating system supports colored fonts, so Brand New Roman C will not appear to be in color when viewed in Font Book etc.**
Colored fonts are supported in Photoshop, Illustrator, and InDesign CC 2018+, and in Firefox and Microsoft Edge. Safari support is expected September of 2018. The monochrome version of Brand New Roman is supported in all programs.

Brand New Roman neither claims nor implies, and in fact explicitly disavows, affiliation with any of the companies who’s logos may appear within the font’s glyph set.

---

Brand New Roman is licensed under the SIL Open Font License, and the license file is included in this package. In short: Brand New Roman may be used for personal and commercial purposes for free and without attribution, and modified at will though you can't call it Brand New Roman anymore if you modify it.

